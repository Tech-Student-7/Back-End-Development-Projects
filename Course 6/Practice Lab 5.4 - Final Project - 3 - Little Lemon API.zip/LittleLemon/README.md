# Hello this is yasmin - welcome to my project.

# Little Lemon API Documentation

## User Types and Default Users

| User Type                    | username | password   |
| ---------------------------- | -------- | ---------- |
| `Manager`<br>`Delivery Crew` | admin    | admin@123! |
| `Manager`                    | kelly    | kelly@123! |
| `Delivery Crew`              | alex     | alex@123!  |
| `Delivery Crew`              | peter    | peter@123! |
| `Customer`                   | ben      | ben@123!   |
| `Customer`                   | dan      | dan@123!   |
| `Customer`                   | ken      | ken@123!   |

User `ken` has already created an order.

## Paths, Methods and Authorizations

### Some `Djoser` default paths 

```
/auth/users
```
```
/auth/users/users/me
```
```
/auth/token/login
```

For details, see [Djoser documentation](https://djoser.readthedocs.io/en/latest/index.html).

### List all categories, create new category

```
/api/categories
```

| Methods | Parameters    | Data Type  | Authorized User Types            | 
| ------- | ------------- | ---------- | -------------------------------- |
| `GET`   | None          | None       | Manager, Delivery Crew, Customer |
| `POST`  | slug<br>title | str<br>str | Manager                          |

### List all menu items, create new menu item

```
/api/menu-items
```

| Methods | Parameters                                | Data Type                            | Authorized User Types            | 
| ------- | ----------------------------------------- | ------------------------------------ | -------------------------------- |
| `GET`   | None                                      | None                                 | Manager, Delivery Crew, Customer |
| `POST`  | title<br>price<br>featured<br>category_id | str<br>float (2 d.p.)<br>bool<br>int | Manager                          |

Default page size: 5

Search fields: title, category_title

Ordering: price, category

### Retrieve single menu item, toggle single menu item `featured` prop

```
/api/menu-items/{menu-item_id}
```

| Methods  | Parameters    | Data Type  | Authorized User Types            | 
| -------- | ------------- | ---------- | -------------------------------- |
| `GET`    | None          | None       | Manager, Delivery Crew, Customer |
| `PATCH`  | None          | None       | Manager                          |

### List all cart items, add new cart item, remove cart item(s)

```
/api/cart/menu-items
```

| Methods  | Parameters          | Data Type | Authorized User Types            | 
| -------- | ------------------- | --------- | -------------------------------- |
| `GET`    | menuitem            | int       | Manager, Delivery Crew, Customer |
| `POST`   | quantity            | int       | Manager, Delivery Crew, Customer |
| `DELETE` | menuitem (optional) | int       | Manager, Delivery Crew, Customer |

For `GET` method, users can only view their own cart items.

For `DELETE` method, if the `id` of a menu item is passed as `menuitem` parameter, the specified cart item will be removed. if the parameter is not present, the cart will be cleared.

Default page size: 5

### List all orders, create new order

```
/api/orders
```

| Methods  | Parameters | Data Type | Authorized User Types            | 
| -------- | ---------- | --------- | -------------------------------- |
| `GET`    | None       | None      | Manager, Delivery Crew, Customer |
| `POST`   | None       | None      | Manager, Delivery Crew, Customer |

For `GET` method, if the user is a `Customer`, only the orders submitted by the user will be returned. If the user is a `Delivery Crew`, only the orders assigned to the user will be returned.

For `POST` method to create a new order, users have to add items to cart before sending the request. All items in cart will be cleared once the new order is successfully created.

Default page size: 5

### Retreive single order, toggle single order `status` prop, delete single order

```
/api/orders/{order_id}
```

| Methods  | Parameters          | Data Type | Authorized User Types            | 
| -------- | ------------------- | --------- | -------------------------------- |
| `GET`    | None                | None      | Manager, Delivery Crew, Customer |
| `PATCH`  | delivery_crew       | str       | Manager                          |
| `PATCH`  | None                | None      | Delivery Crew                    |
| `DELETE` | None                | None      | Manager                          |

For `PATCH` method, if the user is `Manager` and the username of a `Delivery Crew` is passed as `delivery_crew` parameter, the specified `Delivery Crew` user will be assigned to the order. If the user is `Delivery Crew`, no parameter is required, and the status of the specified order will be toggled (from `False` to `True` and vice versa).

### List all users in a group, add new user to a group

```
/api/groups/{group_name}/users
```

| Methods  | Parameters | Data Type | Authorized User Types | 
| -------- | ---------- | --------- | --------------------- |
| `GET`    | None       | None      | Manager               |
| `POST`   | username   | str       | Manager               |

### Remove single user from a group

```
/api/groups/{group_name}/users/{user_id}
```

| Methods  | Parameters | Data Type | Authorized User Types | 
| -------- | ---------- | --------- | --------------------- |
| `DELETE` | None       | None      | Manager               |
